let displayValue = '';
let displayColor = '#000'; // default color

function appendNumber(num) {
    displayValue += num;
    updateDisplay();
}

function appendDecimal() {
    if (!displayValue.includes('.')) {
        displayValue += '.';
        updateDisplay();
    }
}

function operate(operator) {
    if (displayValue !== '' && !isNaN(displayValue[displayValue.length - 1])) {
        displayValue += operator;
        updateDisplay();
    }
}

function calculate() {
    if (displayValue !== '' && !isNaN(displayValue[displayValue.length - 1])) {
        try {
            displayValue = eval(displayValue);
            displayColor = '#000'; // change display color to black
            updateDisplay();
        } catch (error) {
            displayValue = 'Error';
            displayColor = 'red'; // change display color to red for error
            updateDisplay();
        }
    }
}

function clearDisplay() {
    displayValue = '';
    updateDisplay();
}

function deleteLastCharacter() {
    displayValue = displayValue.slice(0, -1);
    updateDisplay();
}

function resetCalculator() {
    displayValue = '';
    displayColor = '#000';
    updateDisplay();
}

function updateDisplay() {
    document.getElementById('display').value = displayValue;
    document.getElementById('display').style.color = displayColor; // update display color
}
